# PARFUM BGM — starter seguro para Cloudflare Pages + Mercado Pago

Este starter publica el storefront estático y usa Cloudflare Pages Functions como backend.
El endpoint `/api/create-checkout` crea un checkout clásico de Mercado Pago Checkout Pro
usando precios definidos en el servidor. Mercado Pago sigue soportando Preferences API,
aunque para nuevas integraciones conviene revisar su Orders API actualizada.

## Qué contiene
- `public/index.html`: tienda inicial; carrito llama al backend de checkout.
- `functions/api/create-checkout.js`: endpoint backend; nunca expone el Access Token.
- `functions/api/mercadopago-webhook.js`: placeholder deliberadamente deshabilitado (501).
- `wrangler.toml`: configuración básica para Cloudflare Pages.

## MUY IMPORTANTE: no aceptar ventas reales todavía
Los tres productos y precios siguen siendo de demostración. El webhook está deshabilitado.
No despaches productos ni marques pedidos como pagados solo por la URL de retorno.
Antes de producción hay que:
1. Sustituir `CATALOG` por productos, precios e inventario reales.
2. Implementar almacenamiento de pedidos y un webhook con verificación criptográfica de firma.
3. En el webhook, consultar el pago/orden directamente a Mercado Pago y validar estado aprobado,
   importe, moneda y referencia antes de confirmar el pedido.
4. Añadir políticas, despacho, cambios/devoluciones, contacto y requisitos tributarios aplicables.
5. Probar pagos de prueba, cancelados, pendientes y aprobados; luego cambiar a credenciales de producción.

## Publicar con Cloudflare Pages
1. Sube el contenido de esta carpeta a un repositorio GitHub nuevo (por ejemplo `parfum-bgm`).
2. En Cloudflare, crea un proyecto Pages conectado a ese repositorio.
3. Configura `public` como directorio de salida/build. No hace falta comando de build para este HTML.
4. En Settings → Variables and Secrets, añade:
   - `MERCADOPAGO_ACCESS_TOKEN` como **secret** (primero credencial de prueba).
   - `PUBLIC_SITE_URL` como variable, por ejemplo la URL HTTPS de Pages que te asignen.
5. Haz un nuevo deploy después de añadir las variables.
6. Prueba la creación de checkout con credenciales de prueba antes de usar credenciales de producción.

No pegues tokens en el HTML, en GitHub, en mensajes, ni en variables públicas. Si un token se filtra,
revócalo desde Mercado Pago y genera otro.

## Consideraciones
- El backend rechaza IDs desconocidos y cantidades inválidas y calcula precios con su catálogo.
- Este ejemplo no guarda órdenes, no calcula despacho ni impuestos, y no valida pagos recibidos.
- No usar el botón de pago en producción hasta implementar el webhook y el flujo de órdenes completo.
