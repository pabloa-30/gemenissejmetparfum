// Placeholder endpoint: Mercado Pago can notify this URL, but this starter does NOT
// mark orders as paid. Before real fulfillment, implement signature verification,
// fetch the payment/order from Mercado Pago with the server token, validate status,
// amount, currency and external_reference, and store the order in a database.
export async function onRequestPost() {
  return new Response("Webhook pendiente de implementación segura", {
    status: 501,
    headers: { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" }
  });
}
