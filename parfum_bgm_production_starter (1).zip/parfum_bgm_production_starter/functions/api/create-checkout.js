// Cloudflare Pages Function: POST /api/create-checkout
// Configure MERCADOPAGO_ACCESS_TOKEN as a Cloudflare Pages secret.
// The server, not the browser, owns the catalog and prices.
const CATALOG = {
  sovereign: { title: "Sovereign — GEMINISEJMET", unit_price: 89990 },
  signature: { title: "Signature — GEMINISEJMET", unit_price: 59990 },
  private: { title: "Private Edition — GEMINISEJMET", unit_price: 149990 }
};

export async function onRequestPost({ request, env }) {
  const token = env.MERCADOPAGO_ACCESS_TOKEN;
  if (!token) return json({ error: "Falta configurar el secreto de Mercado Pago en el servidor." }, 500);

  let body;
  try { body = await request.json(); }
  catch { return json({ error: "Solicitud inválida." }, 400); }

  if (!Array.isArray(body.items) || body.items.length < 1 || body.items.length > 10) {
    return json({ error: "Carrito inválido." }, 400);
  }

  const seen = new Set();
  const items = [];
  for (const row of body.items) {
    if (!row || typeof row.id !== "string" || seen.has(row.id) ||
        !Number.isInteger(row.quantity) || row.quantity < 1 || row.quantity > 10 ||
        !Object.prototype.hasOwnProperty.call(CATALOG, row.id)) {
      return json({ error: "Producto o cantidad inválida." }, 400);
    }
    seen.add(row.id);
    const product = CATALOG[row.id];
    items.push({
      id: row.id,
      title: product.title,
      quantity: row.quantity,
      currency_id: "CLP",
      unit_price: product.unit_price
    });
  }

  // Use the public production URL configured in Pages, not a URL sent by the browser.
  const siteUrl = env.PUBLIC_SITE_URL;
  if (!siteUrl || !/^https:\/\/[a-z0-9.-]+(?::\d+)?$/i.test(siteUrl)) {
    return json({ error: "Configura PUBLIC_SITE_URL con la URL HTTPS pública de la tienda." }, 500);
  }

  const externalReference = crypto.randomUUID();
  const payload = {
    items,
    external_reference: externalReference,
    back_urls: {
      success: `${siteUrl}/?payment=success`,
      pending: `${siteUrl}/?payment=pending`,
      failure: `${siteUrl}/?payment=failure`
    },
    auto_return: "approved",
    notification_url: `${siteUrl}/api/mercadopago-webhook`
  };

  let mpResponse;
  try {
    mpResponse = await fetch("https://api.mercadopago.com/checkout/preferences", {
      method: "POST",
      headers: {
        "Authorization": `Bearer ${token}`,
        "Content-Type": "application/json"
      },
      body: JSON.stringify(payload)
    });
  } catch {
    return json({ error: "No fue posible contactar a Mercado Pago." }, 502);
  }

  const result = await mpResponse.json().catch(() => ({}));
  if (!mpResponse.ok || !result.init_point) {
    // Do not log or return credentials.
    return json({ error: "Mercado Pago no pudo crear el checkout. Revisa credenciales y configuración." }, 502);
  }

  return json({ checkout_url: result.init_point, reference: externalReference });
}

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" }
  });
}
